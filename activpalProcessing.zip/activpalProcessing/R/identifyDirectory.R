identifyDirectory <-
function(path)
{
	directory <- path
	return(directory)
}
